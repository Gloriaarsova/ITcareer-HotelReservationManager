﻿namespace HotelReservationsManager.Data.Models
{
    public enum TypeRoom
    {
        TwoSingleBeds,
        Apartment,
        DoubleBedRoom,
        Penthouse,
        Maisonette
    }
}